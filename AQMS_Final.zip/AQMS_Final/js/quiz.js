$(function() {
    var dialog, form,

        name1 = $("#name1"),
        number = 1,

        allFields = $([]).add(name1),
        tips = $(".validateTips");

    function updateTips(t) {
        tips
            .text(t)
            .addClass("ui-state-highlight");
        setTimeout(function() {
            tips.removeClass("ui-state-highlight", 1500);
        }, 500);
    }

    function checkLength(o, n, min, max) {
        if (o.val().length > max || o.val().length < min) {
            o.addClass("ui-state-error");
            updateTips("Length of " + n + " must be between " +
                min + " and " + max + ".");
            return false;
        } else {
            return true;
        }
    }

    function checkRegexp(o, regexp, n) {
        if (!(regexp.test(o.val()))) {
            o.addClass("ui-state-error");
            updateTips(n);
            return false;
        } else {
            return true;
        }
    }

    function addUser() {
        var valid = true;
        var m = "manage";
        allFields.removeClass("ui-state-error");

        valid = valid && checkLength(name1, "username", 0, 16);
        valid = valid && checkRegexp(name1, /^[a-z]([0-9a-z_\s])+$/i, "Please enter Valid Quiz Title.");

        if (valid) {
            $("#users tbody").append("<tr>" +
                "<td>" + number + "</td>" +
                "<td>" + name1.val() + "</td>" +
                "<td>" + "<button>" + "Edit" + "</td>" +
                "</tr>");
            number++;
            dialog.dialog("close");
        }
        return valid;
    }

    dialog = $("#dialog-form").dialog({
        autoOpen: false,
        height: 400,
        width: 350,
        modal: true,
        buttons: {
            "Save": addUser,
            Cancel: function() {
                dialog.dialog("close");
            }
        },
        close: function() {
            form[0].reset();
            allFields.removeClass("ui-state-error");
        }
    });

    form = dialog.find("form").on("submit", function(event) {
        event.preventDefault();
        addUser();
    });

    $("#create-user").button().on("click", function() {
        dialog.dialog("open");
    });
});

$(function() {
    var dialog, form,

        name1 = $("#name1"),
        number = 1,

        allFields = $([]).add(name1),
        tips = $(".validateTips");

    function updateTips(t) {
        tips
            .text(t)
            .addClass("ui-state-highlight");
        setTimeout(function() {
            tips.removeClass("ui-state-highlight", 1500);
        }, 500);
    }

    function checkLength(o, n, min, max) {
        if (o.val().length > max || o.val().length < min) {
            o.addClass("ui-state-error");
            updateTips("Length of " + n + " must be between " +
                min + " and " + max + ".");
            return false;
        } else {
            return true;
        }
    }

    function checkRegexp(o, regexp, n) {
        if (!(regexp.test(o.val()))) {
            o.addClass("ui-state-error");
            updateTips(n);
            return false;
        } else {
            return true;
        }
    }

    function addUser1() {
        var valid = true;
        var m = "manage";
        allFields.removeClass("ui-state-error");

        valid = valid && checkLength(name1, "username", 0, 16);
        valid = valid && checkRegexp(name1, /^[a-z]([0-9a-z_\s])+$/i, "Please enter Valid Student ID.");

        if (valid) {
            $("#users1 tbody").append("<tr>" +
                "<td>" + number + "</td>" +
                "<td>" + name1.val() + "</td>" +
                "<td>" + "<button>" + "Edit" + "</td>" +
                "</tr>");
            number++;
            dialog.dialog("close");
        }
        return valid;
    }

    dialog = $("#dialog-form2").dialog({
        autoOpen: false,
        height: 400,
        width: 350,
        modal: true,
        buttons: {
            "Save": addUser1,
            Cancel: function() {
                dialog.dialog("close");
            }
        },
        close: function() {
            form[0].reset();
            allFields.removeClass("ui-state-error");
        }
    });

    form = dialog.find("form").on("submit", function(event) {
        event.preventDefault();
        addUser1();
    });

    $("#add-student").button().on("click", function() {
        dialog.dialog("open");
    });
});