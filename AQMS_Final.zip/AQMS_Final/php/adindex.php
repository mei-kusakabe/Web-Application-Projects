<?php include('server.php'); 
if(empty($_SESSION['ademail'])){
	header('location: adminLogin.php');
}
?>
<html>
<head>
	<title>Homepage for Registration</title>
	<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
</head>
<body  style="background-image: url('../img/bg.jpeg');  backdrop-filter: blur(7px);">
	<!-- <center><h1>This is the homepage</h1></center> -->
	<br>
	<div class="content">
			<?php if(isset($_SESSION['success'])) : ?>
			<h3>
		<?php
			echo $_SESSION['success'];
			unset($_SESSION['success']);

	     ?>
	     
		   </h3>
	  
    <?php endif ?>



<?php if(isset($_SESSION["ademail"])): ?>
	<center>
	<h1>Welcome <strong><?php echo $_SESSION["ademail"]; ?></strong></h1>
	<p><a href="../html/adminDashboard.html" class="menu-link">Go to Admin Dashboard</a></p> 
    <p><a href="adminLogin.php?adlogout='1'" style="color: red;">Logout</a></p>
</center>

<?php endif ?>
</div>

</body>
</body>
</html>
