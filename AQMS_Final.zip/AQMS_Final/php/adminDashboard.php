<?php include('server.php'); 
if(empty($_SESSION['ademail'])){
	header('location: adminLogin.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel='stylesheet' href="../css/home.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.css">
  <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
  <title>Admin Dashboard Page</title>
</head>

<body class="flex flex-col items-center font-sans">
  <header class="w-full border-b-4 border-black px-4  mt-4">
    <nav class="navbar">
      <div class="branding">
        <img class="branding-logo" src="../img/logo.png" width="80" height="60">
      </div>
      <label for="input-hamburger" class="hamburger"></label>
      <input type="checkbox" id="input-hamburger" hidden />
      <ul class="menu">
        <li><a href="../html/home.html" class="menu-link">Home</a></li>

        <li class="has-dropdown">
          <a href="" class="menu-link">Teacher&nbsp;<span class="arrow"></span>
          </a>
          <ul class="submenu">
            <li><a href="../php/teacherLogin.php" class="menu-link">Login as Teacher</a></li>
            <li>
              <a href="../php/teacherRegistration.php" class="menu-link">Register as Teacher</a>
            </li>
          </ul>
        </li>

        <li class="has-dropdown">
          <a href="" class="menu-link">Student
            <span class="arrow"></span>
          </a>
          <ul class="submenu">
            <li><a href="../php/studentLogin.php" class="menu-link">Login as Student</a></li>
            <li>
              <a href="../php/studentRegistration.php" class="menu-link">Register as Student</a>
            </li>
          </ul>
        </li>

        <li class="has-dropdown">
          <a href="" class="menu-link">Admin
            <span class="arrow"></span>
          </a>
          <ul class="submenu">
            <li><a href="../php/adminLogin.php" class="menu-link">Login as Admin</a></li>
          </ul>
        </li>

        <li><a href="../html/about.html" class="menu-link">About Us</a></li>
        <li><a href="../html/feedback.html" class="menu-link">Feedback</a></li>
        <li><a href="../html/home.html" class="menu-link">Logout</a></li>
      </ul>
    </nav>
    <script src="../js/nav.js"></script>
  </header>

  <div class="mt-24 w-3/4 p-12 flex flex-col items-center">
  <?php if(isset($_SESSION["ademail"])): ?>
	<center>
	<h1 class="pb-1 font-bold text-2xl">Welcome <strong><?php echo $_SESSION["ademail"]; ?></strong></h1>
<!--	<p><a href="../html/adminDashboard.html" class="menu-link">Go to Admin Dashboard</a></p> 
    <p><a href="adminLogin.php?adlogout='1'" style="color: red;">Logout</a></p>-->
</center>

<?php endif ?>
    <h1 class="pb-1 font-bold text-2xl">Check Out Teacher & Student Info!</h1>
    <br /><br />
    <div class="flex">
      <button class="btn" onclick="location.href='../html/teacherInfo.html'">
        Teacher</button>&nbsp;&nbsp;
      <button class="btn" onclick="location.href='../html/studentInfo.html'">
        Student</button>&nbsp;&nbsp;
    </div>
  </div>
</body>
<div
  class="p-4 mt-56 w-full flex flex-col items-center border-t-2 border-black bg-black bg-opacity-50 text-l font-semibold">
  <div class="flex items-center"> Developed By</div>
  <br />
  <p>Nishi, &nbsp; Aymon, &nbsp; Jafrin.</p>
</div>

</html>