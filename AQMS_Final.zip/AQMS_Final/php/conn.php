<?php
function DBConnect ()
{
    $db = mysqli_connect ("localhost", "root", "", "aqms") or die (mysqli_connect_error());
    return $db;
}

function DBClose($db)
{
    mysqli_close($db) or die (mysqli_error($db));
}

function DBExecute($sql)
{
    $db = DBConnect();
    $result = mysqli_query($db,$sql);
    DBClose($db);
    return $result;
}

function DBRead11()
{
    $sql="SELECT cid, name FROM courses";
    $result=DBExecute($sql);
    while($res=mysqli_fetch_assoc($result))
    {
        $dts[]=$res;
    }
    return $dts;
}

function DBRead12()
{
    $sql="SELECT id, name FROM classes";
    $result=DBExecute($sql);
    while($res=mysqli_fetch_assoc($result))
    {
        $dts2[]=$res;
    }
    return $dts2;
}
function DBRead13()
{
    $sql="SELECT student.stu_id, student.name, attendance.total FROM student INNER JOIN attendance ON student.stu_id=attendance.stu_id";
    $result=DBExecute($sql);
    while($res=mysqli_fetch_assoc($result))
    {
        $dts3[]=$res;
    }
    sort($dts3);
    return $dts3;
}
?>