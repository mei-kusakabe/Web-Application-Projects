<?php include('server.php'); 
if(empty($_SESSION['stu_id'])){
	header('location: studentLogin.php');
}
?>
<html>
<head>
<center><title>Homepage for Registration</title></center>
	<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
</head>
<body  style="background-image: url('../img/bg.jpeg');  backdrop-filter: blur(7px);">
<br>
<br>
<!-- <center><h1>Welcome to homepage</h1></center> -->
	<!--<br>-->
	<div class="content">
			<?php if(isset($_SESSION['success'])) : ?>
			<h3>
		<?php
			echo $_SESSION['success'];
			unset($_SESSION['success']);

	     ?>
	     
		   </h3>
	  
    <?php endif ?>



<?php if(isset($_SESSION["stu_id"])): ?>
<center>
	<h1>Welcome <strong><?php echo $_SESSION["stu_id"]; ?></strong></h1>
	<p><a href="../html/studentDashboard.html" class="menu-link">Go to Student Dashboard</a></p> 
	<!-- <p><a href="../html/studentDashboard.html" style="color: red;">Logout</a></p> -->
	
    <p><a href="studentLogin.php?logout='1'" style="color: red;">Logout</a></p>
	
</center>

<?php endif ?>
</div>

</body>
</body>
</html>
