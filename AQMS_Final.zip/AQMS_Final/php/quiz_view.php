<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href=" https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet" />
    <link rel='stylesheet' href="../css/quiz1.css">
    <link rel="stylesheet" href="../css/quiz.css">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
    <style>
    label,
    input {
        display: block;
    }

    input.text {
        margin-bottom: 12px;
        width: 95%;
        padding: .4em;
    }

    fieldset {
        padding: 0;
        border: 0;
        margin-top: 25px;
    }

    .ui-dialog .ui-state-error {
        padding: .3em;
    }

    .validateTips {
        border: 1px solid transparent;
        padding: 0.3em;
    }
    </style>
    <script>
    $(function() {
        var dialog, form,
            name1 = $("#name1"),
            name2 = $("#name2"),
            name3 = $("#name3"),
            number = 2,
            allFields = $([]).add(name1).add(name2).add(name3),
            tips = $(".validateTips");

        function updateTips(t) {
            tips
                .text(t)
                .addClass("ui-state-highlight");
            setTimeout(function() {
                tips.removeClass("ui-state-highlight", 1500);
            }, 500);
        }

        function checkLength(o, n, min, max) {
            if (o.val().length > max || o.val().length < min) {
                o.addClass("ui-state-error");
                updateTips("Length of " + n + " must be between " +
                    min + " and " + max + ".");
                return false;
            } else {
                return true;
            }
        }

        function checkRegexp(o, regexp, n) {
            if (!(regexp.test(o.val()))) {
                o.addClass("ui-state-error");
                updateTips(n);
                return false;
            } else {
                return true;
            }
        }

        function addUser() {
            var valid = true;
            allFields.removeClass("ui-state-error");
            valid = valid && checkLength(name1, "username", 0, 16);
            valid = valid && checkRegexp(name1, /^[a-z]([0-9a-z_\s])+$/i, "Please enter Valid Quiz Title.");
            valid = valid && checkLength(name2, "username", 0, 16);
            valid = valid && checkRegexp(name2, /^([0-9a-z_\s])+$/i, "Please enter minimum Number.");
            if (valid) {
                $("#users tbody").append("<tr><td class='p-3 text-center'>" + name1.val() +
                    "</td><td class='p-3 text-center'><a href='' class='bg-green-900 hover:bg-green-700 text-white font-bold py-2 px-4 border border-green-500 rounded-md'>Edit</a></td></tr>"
                );
                dialog.dialog("close");
            }
            return valid;
        }

        dialog = $("#dialog-form").dialog({
            autoOpen: false,
            height: 400,
            width: 350,
            modal: true,
            buttons: {
                "Save": addUser,
                Cancel: function() {
                    dialog.dialog("close");
                }
            },
            close: function() {
                form[0].reset();
                allFields.removeClass("ui-state-error");
            }
        });

        form = dialog.find("form").on("submit", function(event) {
            event.preventDefault();
            addUser();
        });

        $("#create-user").button().on("click", function() {
            dialog.dialog("open");
        });
    });
    </script>
    <title>Quiz Management</title>
</head>

<body class="flex flex-col items-center font-sans">
    <header class="w-full border-b-4 border-black px-4  mt-4">
        <nav class="navbar">
            <div class="branding">
                <img class="branding-logo" src="../img/logo.png" width="80" height="60">
            </div>
            <label for="input-hamburger" class="hamburger"></label>

            <ul class="menu">
                <li><a href="../html/home.html" class="menu-link">Home</a></li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Teacher&nbsp;<span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/teacherLogin.php" class="menu-link">Login as Teacher</a></li>
                        <li>
                            <a href="../php/teacherRegistration.php" class="menu-link">Register as Teacher</a>
                        </li>
                    </ul>
                </li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Student
                        <span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/studentLogin.php" class="menu-link">Login as Student</a></li>
                        <li>
                            <a href="../php/studentRegistration.php" class="menu-link">Register as Student</a>
                        </li>
                    </ul>
                </li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Admin
                        <span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/adminLogin.php" class="menu-link">Login as Admin</a></li>
                    </ul>
                </li>

                <li><a href="../html/about.html" class="menu-link">About Us</a></li>
                <li><a href="../html/feedback.html" class="menu-link">Feedback</a></li>
                <li><a href="../html/home.html" class="menu-link">Logout</a></li>
            </ul>
        </nav>
        <script src="../js/nav.js"></script>
    </header>
    <div id="dialog-form" title="Add New Question">
        <form class="my-2">
            <fieldset>
                <label for="name">Question</label>
                <input type="text" name="name1" id="name1" required="required" value=""
                    class="text ui-widget-content ui-corner-all">
                <label for="name">Options:</label>
                <input type="text" name="name2" id="name2" required="required" value=""
                    class="text ui-widget-content ui-corner-all">
                <label class="radio-inline">
                    <input type="radio" style="display: inline;">&nbsp;Question Answer
                </label><br />
                <input type="text" name="name2" id="name2" required="required" value=""
                    class="text ui-widget-content ui-corner-all">
                <label class="radio-inline">
                    <input type="radio" name="optradio" style="display: inline;">&nbsp;Question Answer
                </label><br />
                <input type="text" name="name2" id="name2" required="required" value=""
                    class="text ui-widget-content ui-corner-all">
                <label class="radio-inline">
                    <input type="radio" name="optradio" style="display: inline;">&nbsp;Question Answer
                </label><br />
                <input type="text" name="name2" id="name2" required="required" value=""
                    class="text ui-widget-content ui-corner-all">
                <label class="radio-inline">
                    <input type="radio" name="optradio" style="display: inline;">&nbsp;Question Answer
                </label>
                <!-- Allow form submission with keyboard without duplicating the dialog button -->
                <input type="submit" tabindex="-1" style="position:absolute; top:-1000px; background-color:blue">
            </fieldset>
        </form>
    </div>
    <div class="p-4 mt-8 ml-20 bg-black bg-opacity-50 w-8/12 h-3/5">
        <br>
        <center>
            <h2 class="text-3xl font-bold">Quiz Management</h2>
        </center>
        <br>
        <div class="px-6 flex">
            <button id="create-user"
                class="bg-green-900 hover:bg-green-500 text-white font-bold hover:text-white py-2 px-4 border border-green-900 hover:border-transparent rounded">
                Add Questions
            </button>&nbsp;&nbsp;
            <button onclick="myFunction()" id="add-student"
                class="bg-green-900 hover:bg-green-500 text-white font-bold hover:text-white py-2 px-4 border border-green-900 hover:border-transparent rounded">
                Add Student
            </button>
        </div>
        <br>
        <div class="px-6 flex">
            <div class="flex-1">
                <h1>Questions:</h1>
                <br>
                <table id="users" class="table bg-black text-gray-200 border-separate space-y-6 text-sm w-4/5">
                    <thead class="bg-black text-gray-200 text-center">
                        <tr>
                            <th class="p-3 text-center w-1/4">Title</th>
                            <th class="p-3 text-center w-2/6">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="p-3 text-center w-1/4">Sample Question</td>
                            <td class="p-3 w-2/6 text-center">
                                <button onclick="location.href=''"
                                    class="bg-green-900 hover:bg-green-700 text-white font-bold py-2 px-4 border border-green-500 rounded-md">
                                    Edit
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="flex-1">
                <h1>Students:</h1>
                <br>
                <table id="student" class="table bg-black text-gray-200 border-separate space-y-6 text-sm w-4/5">
                    <thead class="bg-black text-gray-200 text-center">
                        <tr>
                            <th class="p-3 text-center w-1/4">Name</th>
                            <th class="p-3 text-center w-2/6">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="p-3 text-center w-1/4">Sam</td>
                            <td class="p-3 w-2/6 text-center">
                                <button onclick="location.href=''"
                                    class="bg-red-900 hover:bg-red-700 text-white font-bold py-2 px-4 border border-red-500 rounded-md">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>
    <br> <br>
    <div class="flex justify-center">
        <a class="text-gray-200 text-xl" href="../php/teacherDashboard.php">Back to Teacher Dashboard
            Page</a>
    </div>

    <script>
    function myFunction() {
        var name = prompt("Please enter your name", "");
        if (name != null) {
            $("#student tbody").append("<tr><td class='p-3 text-center'>" + name +
                "</td><td class='p-3 text-center'><a href='' class='bg-red-900 hover:bg-red-700 text-white font-bold py-2 px-4 border border-red-500 rounded-md'>Delete</a></td></tr>"
            );
        }
    }
    </script>
</body>
<div
    class="p-4 mt-40 w-full flex flex-col items-center border-t-2 border-black bg-black bg-opacity-50 text-l font-semibold">
    <div class="flex items-center"> Developed By</div>
    <p>Nishi, &nbsp; Aymon, &nbsp; Jafrin.</p>
</div>

</html>