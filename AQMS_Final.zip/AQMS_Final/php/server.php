<?php
session_start();

//initialising variables
$servername = "localhost";
$email = "";
$password = "";
$stu_id ="";
$ademail = "";
$errors = array();

//connect to db
$db = mysqli_connect('localhost','root','','aqms')or die("could not connect to database");

//register student
 if(isset($_POST['register'])){

    $stu_id = mysqli_real_escape_string($db, $_POST['stu_id']);
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $pass_1 = mysqli_real_escape_string($db, $_POST['pass_1']);
    $pass_2 = mysqli_real_escape_string($db, $_POST['pass_2']);


//form validation
//CHECK DB FOR EXISTING MEMBER WITH SAME EMAIL
$member_check_query ="SELECT * FROM student WHERE  email='$email' LIMIT 1";

$results = mysqli_query($db,$member_check_query);
$member = mysqli_fetch_assoc($results);

if($member)
{

    if($member['email'] === $email)
        {
            array_push($errors,"This email id already has a registered Member");
        }

}

//Register the user if no error

if(count($errors) == 0 )
{
   // $password = password_hash($pass_1, PASSWORD_DEFAULT);
    $password = $pass_1;
    $query = "INSERT INTO student (email,name,stu_id,password) VALUES ('$email','$name','$stu_id','$password')";

    mysqli_query($db,$query);
    $_SESSION['stu_id'] = $stu_id;
    $_SESSION['success'] = "You are now  logged in";
    header("location:studentDashboard.php");
}

}
// student login

if(isset($_POST['login'])){

    // $db = mysqli_connect('localhost','root','','aqms')or die("could not connect to database");
    $stu_id = mysqli_real_escape_string($db, $_POST['stu_id']);
    $password = mysqli_real_escape_string($db, $_POST['password']);

    if(empty($stu_id)){
        array_push($errors,"ID is Required");
    }
    if(empty($password)){
        array_push($errors,"Password is Required");
    }

    if(count($errors)== 0 ){
    
   // $password = password_hash($password, PASSWORD_DEFAULT);
    $query = "SELECT * FROM student WHERE  stu_id = '$stu_id' AND password = '$password' ";

    $result= mysqli_query($db,$query);
     
    if(mysqli_num_rows($result) == 1){

    // array_push($errors,"succes"); //check login er kaaj hocche kina
    $_SESSION['stu_id'] = $stu_id;
    $_SESSION['success'] = "You are now  logged in";
    header("location:studentDashboard.php");
    }else{
         array_push($errors,"Wrong ID or password");
    }
   }
}
//student logout
   if(isset($_GET['logout']))
   {
    session_destroy();
    unset($_SESSION['stu_id']);
    header('location: studentLogin.php');
   }

   //Admin Login

   if(isset($_POST['adlogin'])){

    // $db = mysqli_connect('localhost','root','','aqms')or die("could not connect to database");
    $ademail = mysqli_real_escape_string($db, $_POST['ademail']);
    $password = mysqli_real_escape_string($db, $_POST['password']);

    if(empty($ademail)){
        array_push($errors,"Admin Email is Required");
    }
    if(empty($password)){
        array_push($errors,"Password is Required");
    }

    if(count($errors)== 0 ){
    
   // $password = password_hash($password, PASSWORD_DEFAULT);
    $query = "SELECT * FROM admin WHERE  ademail = '$ademail' AND password = '$password' ";

    $result= mysqli_query($db,$query);
     
    if(mysqli_num_rows($result) == 1){

    // array_push($errors,"succes"); //check login er kaaj hocche kina
    $_SESSION['ademail'] = $ademail;
    $_SESSION['success'] = "You are now  logged in";
    header("location:adminDashboard.php");
    }else{
         array_push($errors,"Wrong Email or password");
    }
   }
}
//admin logout
   if(isset($_GET['adlogout']))
   {
    session_destroy();
    unset($_SESSION['ademail']);
    header('location: adminLogin.php');
   }

$db->close();

?>
