<?php
include('conn.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel='stylesheet' href="../css/home.css">
    <link href=" https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet" />
    <title>Attendance</title>
    <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>

    <script>
    let name = ['aymon', 'nishi', 'jafrin'];
    let id = [1, 2, 3];
    let sl = [1, 2, 3];
   // const excel_file = document.getElementById('excel_file');
    excel_file.addEventListener('change', (event) => {
        var reader = new FileReader();
        reader.readAsArrayBuffer(event.target.files[0]);
        reader.onload = function(event) {
            var data = new Uint8Array(reader.result);
            var work_book = XLSX.read(data, {
                type: 'array'
            });
            var sheet_name = work_book.SheetNames;
            var sheet_data = XLSX.utils.sheet_to_json(work_book.Sheets[sheet_name[0]], {
                header: 1
            });
            if (sheet_data.length > 0) {
                var i = 3;
                for (var row = 0; row < sheet_data.length; row++) {
                    for(var cell = 0; cell < sheet_data[row].length; cell++)
                    sl[i + row] = i + row;
                    name[i + row] = sheet_data[row][0];
                    id[i + row] = sheet_data[row][1];
                }
            }
        }
    });
    var tbl = document.createElement("table");
    var tblBody = document.createElement("tbody");
    for (var i = 0; i < sl.length; i++) {
        var row = document.createElement("tr");
        var cell = document.createElement("td");
        var cellText = document.createTextNode(sl[i] + name[i] + id[i]);
        cell.appendChild(cellText);
        row.appendChild(cell);
        tblBody.appendChild(row);
    }
    // put the <tbody> in the <table>
    tbl.appendChild(tblBody);
    </script>
</head>

<body class="flex flex-col items-center font-sans">
    <header class="w-full border-b-4 border-black px-4 mt-4">
        <nav class="navbar">
            <div class="branding">
                <img class="branding-logo" src="../img/logo.png" width="80" height="60">
            </div>
            <label for="input-hamburger" class="hamburger"></label>
            <input type="checkbox" id="input-hamburger" hidden />
            <ul class="menu">
                <li><a href="../html/home.html" class="menu-link">Home</a></li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Teacher&nbsp;<span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/teacherLogin.php" class="menu-link">Login as Teacher</a></li>
                        <li>
                            <a href="../php/teacherRegistration.php" class="menu-link">Register as Teacher</a>
                        </li>
                    </ul>
                </li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Student
                        <span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/studentLogin.php" class="menu-link">Login as Student</a></li>
                        <li>
                            <a href="../php/studentRegistration.php" class="menu-link">Register as Student</a>
                        </li>
                    </ul>
                </li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Admin
                        <span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/adminLogin.php" class="menu-link">Login as Admin</a></li>
                    </ul>
                </li>

                <li><a href="../html/about.html" class="menu-link">About Us</a></li>
                <li><a href="../html/feedback.html" class="menu-link">Feedback</a></li>
                <li><a href="../html/home.html" class="menu-link">Logout</a></li>
            </ul>
        </nav>
        <script src="../js/nav.js"></script>
    </header>

    <div class="p-2 mt-4 ml-20 bg-black bg-opacity-50 w-8/12 h-2/3 justify-center items-center">
        <center>
            <h2 class="text-2xl font-bold">Attendance Sheet</h2>
        </center>
        <br>
        <div class="px-6 flex justify-between">
            <b>Select Excel File</b>
            <button onclick="location.href=''"
                class="bg-green-900 hover:bg-green-500 text-white font-bold py-2 px-4 border border-green-900 hover:border-transparent rounded">
                Add New Student
            </button>
        </div>
        <div class="px-6">
            <input type="file" id="excel_file" />
        </div>
        <!--<h1 class="font-semibold text-gray-200 py-2 text-center">Total Class Taken: 10</h1>-->
        <br>
        <div id="excel_data" class="px-6 flex justify-around">
        <form method="post" action="update.php">
            <table class="table bg-black text-gray-200 border-separate space-y-6 text-sm w-4/5">
                <thead class="bg-black text-gray-200 text-center">
                    <tr>
                        <th class="p-3 text-center">#</th>
                        <th class="p-3 text-center w-1/4">Name</th>
                        <th class="p-3 text-center">ID</th>
                        <th class="p-3 text-center">Attendance</th>
                        <th class="p-3 text-center w-2/6">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $dts3 = DBRead13();  
               ?>
                <?php
                $i=1;
                    foreach($dts3 as $student) { ?>
                   <tr>
                   <td class="p-3 text-center"><?php echo $i++ ; ?></td>
                    <td class="p-3 text-center w-1/4"><?php echo $student["stu_id"]; ?></td>
                    <td class="p-3 text-center w-1/4"><?php echo $student["name"]; ?></td>
                    <td class="p-3 text-center w-1/4"><?php echo $student["total"]; ?></td>
                    <input type="hidden" name="chkl[ ]" value="0">
                    <td class="p-3 text-center w-1/4"><input type=checkbox name="chkl[ ]" value="1" onclick="getatt(this.checked);"/></td>
                    </td></tr>
                <?php
                }
                ?>
            </tbody>
            </table>
            <input type="submit" value="Get Attendance" name="btnsubmit" class="ml-24 my-2 items-center w-1/2 bg-green-900 hover:bg-green-700 text-white font-bold px-4 border border-green-500 rounded-md"/>
            </form>
            <table width="100px" align="right" style="margin-left:35px">
                <tr><td> Total Present: <input type="text" id="txtPresent" value="0" size="8"  disabled="disabled"/></td></tr>
             </table>
            
           
        </div>
        <script type="text/javascript">
	function getatt(value)
	{
		if(value == true)
		{
			//document.getElementById("txtAbsent").value = parseInt(document.getElementById("txtAbsent").value) - 1;
			document.getElementById("txtPresent").value = parseInt(document.getElementById("txtPresent").value) + 1;
		}
		else
		{
			//document.getElementById("txtAbsent").value = parseInt(document.getElementById("txtAbsent").value) + 1;
			document.getElementById("txtPresent").value = parseInt(document.getElementById("txtPresent").value) - 1;
		}
	}
</script>

</div>
    </div>
    <br />
    <div class="flex justify-center">
        <a class="text-gray-200 text-xl" href="../php/teacherDashboard.php">Back to Teacher Dashboard
            Page</a>
    </div>
</body>
<div
    class="p-4 mt-10 w-full flex flex-col items-center border-t-2 border-black bg-black bg-opacity-50 text-l font-semibold">
    <div class="flex items-center"> Developed By</div>
    <p>Nishi, &nbsp; Aymon, &nbsp; Jafrin.</p>
</div>

</html>