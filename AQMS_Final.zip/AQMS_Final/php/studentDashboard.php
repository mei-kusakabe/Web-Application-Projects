<?php include('server.php'); 
if(empty($_SESSION['stu_id'])){
	header('location: studentLogin.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel='stylesheet' href="../css/home.css">
    <link href=" https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet" />
    <title>Student Dashboard</title>
    <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
</head>

<body class="flex flex-col items-center font-sans">
    <header class="w-full border-b-4 border-black px-4  mt-4">
        <nav class="navbar">
            <div class="branding">
                <img class="branding-logo" src="../img/logo.png" width="80" height="60">
            </div>
            <label for="input-hamburger" class="hamburger"></label>
            <input type="checkbox" id="input-hamburger" hidden />
            <ul class="menu">
                <li><a href="../html/home.html" class="menu-link">Home</a></li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Teacher&nbsp;<span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/teacherLogin.php" class="menu-link">Login as Teacher</a></li>
                        <li>
                            <a href="../php/teacherRegistration.php" class="menu-link">Register as Teacher</a>
                        </li>
                    </ul>
                </li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Student
                        <span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/studentLogin.php" class="menu-link">Login as Student</a></li>
                        <li>
                            <a href="../php/studentRegistration.php" class="menu-link">Register as Student</a>
                        </li>
                    </ul>
                </li>

                <li class="has-dropdown">
                    <a href="" class="menu-link">Admin
                        <span class="arrow"></span>
                    </a>
                    <ul class="submenu">
                        <li><a href="../php/adminLogin.php" class="menu-link">Login as Admin</a></li>
                    </ul>
                </li>

                <li><a href="../html/about.html" class="menu-link">About Us</a></li>
                <li><a href="../html/feedback.html" class="menu-link">Feedback</a></li>
                <li><a href="../html/home.html" class="menu-link">Logout</a></li>
            </ul>
        </nav>
        <script src="../js/nav.js"></script>
    </header>

    <div class="p-4 mt-24 ml-20 bg-black bg-opacity-50 w-8/12 h-3/5 justify-center items-center">
   
        <?php if(isset($_SESSION["stu_id"])): ?>
<center>
	<h1 class="text-2xl py-2">Welcome <strong><?php echo $_SESSION["stu_id"]; ?></strong></h1>
	<!--<p><a href="../html/studentDashboard.html" class="menu-link">Go to Student Dashboard</a></p> 
	<!-- <p><a href="../html/studentDashboard.html" style="color: red;">Logout</a></p> 
	
    <p><a href="studentLogin.php?logout='1'" style="color: red;">Logout</a></p>-->
	
</center>

<?php endif ?>
        <center>
            <h2 class="text-3xl font-bold">My Quiz List</h2>
        </center>
        <br><br>
        <div class="px-6 flex flex-col justify-center items-center">
            <table class="table bg-black text-gray-200 border-separate space-y-6 text-sm w-4/5">
                <thead class="bg-black text-gray-200 text-center">
                    <tr>
                        <th class="p-3 text-center">#</th>
                        <th class="p-3 text-center w-1/4">Quiz</th>
                        <th class="p-3 text-center">Score</th>
                        <th class="p-3 text-center">Status</th>
                        <th class="p-3 text-center w-2/6">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="p-3 text-center">1</td>
                        <td class="p-3 text-center w-1/4">Computer Graphics</td>
                        <td class="p-3 text-center">10</td>
                        <td class="p-3 text-center">
                            <span class="bg-green-400 text-gray-50 rounded-sm px-2">Completed</span>
                        </td>
                        <td> </td>
                    </tr>
                    <tr>
                        <td class="p-3 text-center">1</td>
                        <td class="p-3 text-center w-1/4">EEE</td>
                        <td class="p-3 text-center">N/A</td>
                        <td class="p-3 text-center">
                            <span class="bg-red-400 text-gray-50 rounded-sm px-2">Pending</span>
                        </td>
                        <td class="p-3 w-2/6 text-center">
                            <button onclick="location.href=''"
                                class="bg-green-900 hover:bg-green-700 text-white font-bold py-2 px-4 border border-green-500 rounded-md">
                                Take Quiz
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
<div
    class="p-4 mt-40 w-full flex flex-col items-center border-t-2 border-black bg-black bg-opacity-50 text-l font-semibold">
    <div class="flex items-center"> Developed By</div>
    <br />
    <p>Nishi, &nbsp; Aymon, &nbsp; Jafrin.</p>
</div>

</html>