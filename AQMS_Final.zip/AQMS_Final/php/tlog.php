<?php
	session_start();
	$conn = new mysqli("localhost", "root", "", "aqms");
    if (!$conn) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
	
	if(ISSET($_POST['login'])){
		$username = $_POST['email'];
		$password = $_POST['password'];
		
		$query = mysqli_query($conn, "SELECT * FROM `faculty` WHERE `email` = '$username' && `password` = '$password'") or die(mysqli_error());
		$fetch = mysqli_fetch_array($query);
		$row = $query->num_rows;
		
		if($row > 0){
			$_SESSION['name'] = $fetch['name'];
			header("location:teacherDashboard.php");
		}else{
			echo "<center><label class='text-danger'>Invalid username or password</label></center>";
		}
	}
?>