<?php
    // create a variable
    $conn = new mysqli("localhost", "root", "", "aqms");
    if (!$conn) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
    //Execute the query
    $sql = "INSERT INTO faculty (name, email, password) VALUES ('$name', '$email', '$pass')";

    if (mysqli_query($conn, $sql)) {
        echo $name . " Registration Completed.";
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }
    // Close connection
    header('location: teacherLogin.php');
?>