<?php

    if(isset($_POST["btnsubmit"]))
	{
		$db = mysqli_connect("localhost","root","","aqms") or die (mysqli_connect_error());
		$query = "select * from `attendance` ";
		$result = mysqli_query($db,$query)or die("select error");
        $checkbox1 = $_POST['chkl'] ; 
        $j=0; 
        while($res=mysqli_fetch_assoc($result))
        {
            $dts2[]=$res;
        }
        sort($dts2);
        for ($i = 0; $i < count($dts2); $i++)
       { 
        //print("$student['stu_id'] $student['total'] $checkbox1[$i] ");
           if($checkbox1[$i])
           {
            $id=$dts2[$i]["id"];
            $mno = $dts2[$i]["stu_id"];
            $tot = $dts2[$i]["total"];
            print("$mno - $tot - $checkbox1[$i] - ");
            $tot++;
            print("$tot , ");
            $query1 = "UPDATE attendance SET total='$tot' WHERE id = $id";
            mysqli_query($db,$query1) or die("insert error".$mno);
           }
           print("\n");
           //$i++;
          // mysqli_query($db,$query1)or die("insert error".$mno);
       }
			print "<script>";
			print "alert('Attendance get successfully....');";
			print "self.location='student.php';";
			print "</script>";
    }
    else{
		header("Location:../php/takeAttendance.php");
	}
?>